from .addons.pt_blender import register as addon_register, unregister as addon_unregister

bl_info = {
    "name": 'Blender-PT-UE',
    "author": '[ma zhi hao]',
    "blender": (4, 3, 0),
    "version": (0, 0, 1),
    "description": '从blender到pt到ue全流程工具(快速制作模型，贴图，导入游戏使用)',
    "warning": '',
    "doc_url": 'https://space.bilibili.com/356962724',
    "tracker_url": '[contact email]',
    "support": 'COMMUNITY',
    "category": '3D View'
}

def register():
    addon_register()

def unregister():
    addon_unregister()

    